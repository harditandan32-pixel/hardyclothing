/*
  ADD YOUR PRODUCTS HERE.
  For each product, change:
  image: "images/your-photo.jpg"
  link: "https://your-buy-link.com"
  name, category, price and size.
*/
const products = [
  {name:"Your T-Shirt", category:"T-Shirts", price:"₹999", size:"M / L / XL", image:"", link:"#"},
  {name:"Your Shirt", category:"Shirts", price:"₹1,499", size:"M / L / XL", image:"", link:"#"},
  {name:"Your Hoodie", category:"Hoodies", price:"₹1,999", size:"M / L / XL", image:"", link:"#"},
  {name:"Your Pants", category:"Pants", price:"₹1,299", size:"28 / 30 / 32", image:"", link:"#"}
];

const grid=document.getElementById("products");
const search=document.getElementById("search");
const category=document.getElementById("category");

function render(){
  const q=search.value.toLowerCase().trim();
  const cat=category.value;
  const filtered=products.filter(p=>
    (cat==="all"||p.category===cat) &&
    (p.name.toLowerCase().includes(q)||p.category.toLowerCase().includes(q))
  );
  grid.innerHTML=filtered.length?filtered.map(p=>`
    <article class="product">
      <div class="product-img">
        ${p.image ? `<img src="${p.image}" alt="${p.name}" style="width:100%;height:100%;object-fit:cover">` : "ADD<br>PHOTO"}
      </div>
      <div class="product-info">
        <h3>${p.name}</h3>
        <div class="meta">${p.category} · ${p.size} · ${p.price}</div>
        <a class="buy" href="${p.link}" target="_blank" rel="noopener">BUY NOW ↗</a>
      </div>
    </article>`).join(""):`<div class="empty">No products found.</div>`;
}
search.addEventListener("input",render);
category.addEventListener("change",render);
render();