# HARDY CLOTHING

A simple premium clothing catalogue website.

## How to add products

Open `script.js` and edit the `products` list.

Example:
{
  name:"Black Oversized Tee",
  category:"T-Shirts",
  price:"₹1,299",
  size:"M / L / XL",
  image:"images/black-tee.jpg",
  link:"https://example.com/buy"
}

Put product photos inside the `images` folder and use their filename in `image`.

For a direct Instagram/WhatsApp/product-page purchase, paste that URL into `link`.

## Preview

Open `index.html` in a browser.

## Publish

Upload the folder to any static website host, then connect your custom domain if you want one.
